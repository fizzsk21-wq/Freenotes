# FreeNote Android (starter)

A free, local-first Android notes app starter inspired by common handwritten notebook apps. It is not affiliated with or a copy of any proprietary FreeNote app.

## Included
- Touch/stylus drawing canvas (works with Android styluses; pressure support depends on device)
- Pen, pencil-style ink, highlighter, eraser
- Ink colour palette and adjustable stroke width
- Blank, ruled, grid and dotted paper
- Create and switch between named notes
- Local PNG persistence and a simple undo stack
- PNG export to app cache (export/share UI can be improved in a later iteration)

## Build an APK
This workspace did not have the Android SDK/Gradle build environment available, so a compiled APK is not included. To build it for free:
1. Install Android Studio on a computer.
2. Open this `FreeNote-Android` folder as a project.
3. Let Android Studio download the Android Gradle Plugin and SDK platform 35.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

No paid SDK or subscription is required. This is an MVP and has not been compiled or device-tested here. It does not yet include PDF import/annotation, cloud sync, lasso selection, OCR/search of handwriting, or a polished system share sheet.

## Build APK in GitHub Actions (no local Android SDK required)
1. Create a GitHub repository and upload the contents of this folder to it.
2. Open the repository's **Actions** tab and run **Build FreeNote APK** (or push to `main`/`master`).
3. When the workflow finishes, open the workflow run and download the `FreeNote-debug-apk` artifact.
4. Extract the artifact ZIP to get `app-debug.apk` and install it on your Android device. Android may ask you to allow installs from your browser/file manager.

This produces a debug APK for personal testing, not a Play Store release.
