package com.example.freenote;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Set;

public class MainActivity extends Activity {
    private DrawView drawView;
    private String activeNote = "My First Note";
    private String tool = "Pen";
    private String paper = "Ruled";
    private int inkColor = Color.BLACK;
    private float strokeWidth = 4f;
    private LinearLayout root;
    private TextView title;
    private final int[] colors = new int[]{Color.BLACK, Color.BLUE, Color.RED, 0xff168447, 0xffff8c00, 0xff8b45bd, 0xffe65b9a, 0xff00a6a6};

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xfff8f7fc);
        getWindow().setNavigationBarColor(0xfff8f7fc);
        buildUi();
    }

    private void buildUi() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(0xfff8f7fc);
        setContentView(root);
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(12, 8, 12, 8);
        title = new TextView(this); title.setText("✎  " + activeNote); title.setTextColor(0xff25233a); title.setTextSize(20); title.setTypeface(null, 1);
        top.addView(title, new LinearLayout.LayoutParams(0, 48, 1));
        addButton(top, "＋ New", v -> newNote()); addButton(top, "Export", v -> exportNote());
        root.addView(top);

        HorizontalScrollView toolsScroll = new HorizontalScrollView(this); toolsScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout tools = new LinearLayout(this); tools.setPadding(8, 4, 8, 4); tools.setGravity(Gravity.CENTER_VERTICAL);
        for (String t : new String[]{"Pen", "Pencil", "Highlighter", "Eraser"}) addButton(tools, t, v -> { tool=t; drawView.invalidate(); toast(t+" selected"); });
        addButton(tools, "Paper", v -> choosePaper());
        addButton(tools, "Notes", v -> chooseNote());
        addButton(tools, "Undo", v -> { drawView.undo(); });
        addButton(tools, "Clear", v -> confirmClear());
        toolsScroll.addView(tools); root.addView(toolsScroll);

        HorizontalScrollView colorsScroll = new HorizontalScrollView(this); colorsScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout palette = new LinearLayout(this); palette.setGravity(Gravity.CENTER_VERTICAL); palette.setPadding(12, 3, 12, 3);
        TextView label = new TextView(this); label.setText("Ink  "); label.setTextColor(0xff55536a); palette.addView(label);
        for (int c : colors) {
            Button b = new Button(this); b.setText("●"); b.setTextSize(19); b.setTextColor(c); b.setMinWidth(42); b.setPadding(0,0,0,0); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xffeeeeF5));
            b.setOnClickListener(v -> { inkColor=c; drawView.invalidate(); }); palette.addView(b);
        }
        colorsScroll.addView(palette); root.addView(colorsScroll);

        LinearLayout widthRow = new LinearLayout(this); widthRow.setGravity(Gravity.CENTER_VERTICAL); widthRow.setPadding(14, 0, 14, 0);
        TextView widthLabel = new TextView(this); widthLabel.setText("Stroke width"); widthLabel.setTextColor(0xff55536a); widthRow.addView(widthLabel);
        SeekBar seek = new SeekBar(this); seek.setMax(35); seek.setProgress(3); seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){ public void onProgressChanged(SeekBar s,int p,boolean u){strokeWidth=Math.max(1,p+1); if(drawView!=null)drawView.setStroke(strokeWidth);} public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){} });
        widthRow.addView(seek, new LinearLayout.LayoutParams(0, 42, 1)); root.addView(widthRow);

        drawView = new DrawView(); root.addView(drawView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        TextView foot = new TextView(this); foot.setText("Saved on this device  •  Draw with your finger or stylus"); foot.setTextColor(0xff77758a); foot.setGravity(Gravity.CENTER); foot.setPadding(6, 8, 6, 10); root.addView(foot);
    }

    private void addButton(LinearLayout row, String text, View.OnClickListener listener) {
        Button b = new Button(this); b.setText(text); b.setTextSize(12); b.setAllCaps(false); b.setPadding(10, 0, 10, 0); b.setMinWidth(0); b.setMinimumWidth(0); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xffe9e7f7)); b.setTextColor(0xff393453); b.setOnClickListener(listener); row.addView(b, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, 42));
    }
    private File noteFile(String name) { String safe=name.replaceAll("[^a-zA-Z0-9._-]", "_"); return new File(getFilesDir(), "note_"+safe+".png"); }
    private Set<String> noteNames() { return new LinkedHashSet<>(getPreferences(0).getStringSet("notes", new LinkedHashSet<String>())); }
    private void rememberNote(String name) { Set<String> names=noteNames(); names.add(name); getPreferences(0).edit().putStringSet("notes", names).apply(); }
    private void newNote() {
        EditText input = new EditText(this); input.setHint("Notebook name");
        new AlertDialog.Builder(this).setTitle("Create a note").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Create", (d,w)->{
            String name=input.getText().toString().trim(); if(name.isEmpty()) name="Untitled Note";
            activeNote=name; rememberNote(name); title.setText("✎  "+activeNote); drawView.clear(false); drawView.loadNote();
        }).show();
    }
    private void chooseNote() {
        Set<String> names=noteNames(); names.add(activeNote); String[] options=names.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("Open note").setItems(options,(d,which)->{drawView.save(); activeNote=options[which]; title.setText("✎  "+activeNote); drawView.loadNote();}).setPositiveButton("Done",null).show();
    }
    private void choosePaper() {
        String[] options={"Blank", "Ruled", "Grid", "Dotted"};
        new AlertDialog.Builder(this).setTitle("Paper template").setSingleChoiceItems(options, java.util.Arrays.asList(options).indexOf(paper),(d,which)->{paper=options[which]; drawView.invalidate(); d.dismiss();}).setNegativeButton("Cancel",null).show();
    }
    private void confirmClear() { new AlertDialog.Builder(this).setTitle("Clear this page?").setMessage("This clears the ink on the current note.").setNegativeButton("Cancel",null).setPositiveButton("Clear",(d,w)->drawView.clear(true)).show(); }
    private void exportNote() {
        try {
            Bitmap out=drawView.exportBitmap(); File f=new File(getCacheDir(), "FreeNote-"+activeNote.replaceAll("[^a-zA-Z0-9_-]","_")+".png");
            FileOutputStream stream=new FileOutputStream(f); out.compress(Bitmap.CompressFormat.PNG,100,stream); stream.close();
            Uri uri=Uri.parse("content://"+getPackageName()+".files/"+f.getName());
            // Share image via Android chooser using a FileProvider-compatible cache URI is not available without a provider;
            // save it to app files and show the location as a safe fallback.
            Toast.makeText(this,"PNG saved inside app cache: "+f.getName(),Toast.LENGTH_LONG).show();
        } catch(Exception e) { Toast.makeText(this,"Export failed: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    private class DrawView extends View {
        private Bitmap ink;
        private Canvas inkCanvas;
        private Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
        private Path path = new Path();
        private float lastX,lastY;
        private final ArrayList<Bitmap> undo = new ArrayList<>();
        private boolean drawing=false;
        DrawView(){super(MainActivity.this); setLayerType(View.LAYER_TYPE_SOFTWARE,null); paint.setStyle(Paint.Style.STROKE); paint.setStrokeCap(Paint.Cap.ROUND); paint.setStrokeJoin(Paint.Join.ROUND); setBackgroundColor(Color.WHITE);}
        void setStroke(float w){strokeWidth=w;}
        @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){super.onSizeChanged(w,h,oldw,oldh); if(w>0&&h>0){ink=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); inkCanvas=new Canvas(ink); loadNote();}}
        void loadNote(){if(ink==null||inkCanvas==null)return; ink.eraseColor(Color.TRANSPARENT); Bitmap saved=BitmapFactory.decodeFile(noteFile(activeNote).getAbsolutePath()); if(saved!=null){inkCanvas.drawBitmap(saved,null,new RectF(0,0,getWidth(),getHeight()),new Paint(Paint.FILTER_BITMAP_FLAG)); saved.recycle();} invalidate();}
        void save(){if(ink==null)return; try(FileOutputStream out=new FileOutputStream(noteFile(activeNote))){ink.compress(Bitmap.CompressFormat.PNG,100,out); rememberNote(activeNote);}catch(Exception ignored){}}
        void clear(boolean save){if(ink!=null)ink.eraseColor(Color.TRANSPARENT); undo.clear(); invalidate(); if(save)save();}
        void undo(){if(!undo.isEmpty()&&inkCanvas!=null){inkCanvas.drawColor(Color.TRANSPARENT,PorterDuff.Mode.CLEAR); inkCanvas.drawBitmap(undo.remove(undo.size()-1),0,0,null); invalidate(); save();}}
        private void snapshot(){if(ink!=null){undo.add(ink.copy(Bitmap.Config.ARGB_8888,false)); if(undo.size()>12)undo.remove(0).recycle();}}
        @Override protected void onDraw(Canvas c){super.onDraw(c); c.drawColor(Color.WHITE); Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); p.setColor(0xffdfe2ee); p.setStrokeWidth(1f); float step= paper.equals("Grid")?28:32;
            if(paper.equals("Ruled")){for(float y=step;y<getHeight();y+=step)c.drawLine(0,y,getWidth(),y,p);} else if(paper.equals("Grid")){for(float x=step;x<getWidth();x+=step)c.drawLine(x,0,x,getHeight(),p);for(float y=step;y<getHeight();y+=step)c.drawLine(0,y,getWidth(),y,p);} else if(paper.equals("Dotted")){p.setStyle(Paint.Style.FILL);for(float x=step;x<getWidth();x+=step)for(float y=step;y<getHeight();y+=step)c.drawCircle(x,y,1.25f,p);}
            if(ink!=null)c.drawBitmap(ink,0,0,null);
        }
        @Override public boolean onTouchEvent(MotionEvent e){float x=e.getX(),y=e.getY(); switch(e.getActionMasked()){
            case MotionEvent.ACTION_DOWN: if(inkCanvas==null)return false; snapshot(); path.reset(); path.moveTo(x,y); lastX=x;lastY=y; drawing=true; return true;
            case MotionEvent.ACTION_MOVE: if(drawing){for(int i=0;i<e.getHistorySize();i++)drawSegment(e.getHistoricalX(i),e.getHistoricalY(i),e.getHistoricalPressure(i)); drawSegment(x,y,e.getPressure()); invalidate();}return true;
            case MotionEvent.ACTION_UP: if(drawing){drawSegment(x,y,e.getPressure()); drawing=false; invalidate(); save();}return true;
            case MotionEvent.ACTION_CANCEL: drawing=false; save(); return true;
        }return true;}
        private void drawSegment(float x,float y,float pressure){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.DITHER_FLAG);p.setStyle(Paint.Style.STROKE);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);p.setStrokeWidth(strokeWidth*(pressure>0?Math.max(.55f,pressure):1f));
            if(tool.equals("Eraser")){p.setColor(Color.TRANSPARENT);p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));p.setStrokeWidth(Math.max(18,strokeWidth*4));}else{p.setColor(inkColor);if(tool.equals("Highlighter")){p.setAlpha(75);p.setStrokeWidth(strokeWidth*4);}else if(tool.equals("Pencil")){p.setAlpha(180);p.setStrokeWidth(Math.max(1,strokeWidth*.8f));}}
            inkCanvas.drawLine(lastX,lastY,x,y,p); lastX=x;lastY=y;
        }
        Bitmap exportBitmap(){Bitmap result=Bitmap.createBitmap(Math.max(1,getWidth()),Math.max(1,getHeight()),Bitmap.Config.ARGB_8888);Canvas c=new Canvas(result); draw(c); return result;}
    }
}
